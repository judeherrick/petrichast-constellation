' ============================================================================
'  Scombinatorial Temple Companion v2  --  MainScene.brs
'  Hybrid of the ECP "weighted hand" channel + the healing-dashboard layer:
'    * luminous anatomical canvas with 7 Solfeggio resonance points
'    * 4-7-8 breath pacer (ring + countdown)
'    * spring-damper "weighted hand" cursor whose mass comes from ECP speed
'    * entropy-driven AMBIENT <-> GROUNDING colour-temperature switching
'    * six live metrics (visual simulation, NOT a medical device)
'    * 5 particle shapes: sustain / bloom / ripple / spiral / storm
'    * remote-control play + live ECP control + two-way HTTP feed
' ============================================================================

sub init()
    m.top.setFocus(true)
    m.PI = 3.14159265
    m.NL = Chr(10)

    ' ---- node handles -------------------------------------------------------
    m.bgWash = m.top.findNode("bgWash")
    m.ringHalo = m.top.findNode("ringHalo")
    m.breathRing = m.top.findNode("breathRing")
    m.bodyPoster = m.top.findNode("bodyPoster")
    m.cursorHalo = m.top.findNode("cursorHalo")
    m.cursorRing = m.top.findNode("cursorRing")
    m.cursorCore = m.top.findNode("cursorCore")
    m.modeLabel = m.top.findNode("modeLabel")
    m.phaseLabel = m.top.findNode("phaseLabel")
    m.phaseSub = m.top.findNode("phaseSub")
    m.telemetryLabel = m.top.findNode("telemetryLabel")
    m.nodeTitle = m.top.findNode("nodeTitle")
    m.nodeFreq = m.top.findNode("nodeFreq")
    m.nodeDesc = m.top.findNode("nodeDesc")
    m.attuneBar = m.top.findNode("attuneBar")
    m.attuneLabel = m.top.findNode("attuneLabel")
    m.logLabel = m.top.findNode("logLabel")
    m.keyLabel = m.top.findNode("keyLabel")
    m.audio = m.top.findNode("tonePlayer")

    m.mv = []
    m.mb = []
    for i = 0 to 5
        m.mv.push(m.top.findNode("mv" + i.toStr()))
        m.mb.push(m.top.findNode("mb" + i.toStr()))
    end for

    ' ---- body points (screen coords = body poster origin 700,100 + offset) ---
    m.nodes = []
    m.nodes.push(mkNode("CROWN", "brain / pineal", 963, 960, 170, "0xB48CFFFF", "Crown / brain. Symbolic point for stillness and awareness. Let thoughts drift past while the ring breathes."))
    m.nodes.push(mkNode("BROW", "eyes / pituitary", 852, 960, 208, "0x6F7CFFFF", "Brow / eyes. Symbolic point for focus and inner sight. Soften the gaze and slow the exhale."))
    m.nodes.push(mkNode("THROAT", "throat / lungs", 741, 960, 290, "0x35C9FFFF", "Throat / voice. Symbolic point for expression. Try a quiet hum on the exhale."))
    m.nodes.push(mkNode("HEART", "heart / circulation", 639, 982, 422, "0x3DFFA0FF", "Heart / circulation. The glow beats with the simulated pulse. Longer exhales settle the rhythm."))
    m.nodes.push(mkNode("SOLAR", "liver / digestion", 528, 960, 520, "0xFFE14DFF", "Solar plexus / digestion. Symbolic point for steadiness. Feel the belly widen on the inhale."))
    m.nodes.push(mkNode("SACRAL", "gut / flow", 417, 960, 640, "0xFF8F3AFF", "Sacral / gut. Symbolic point for flow and ease. Let the low belly soften."))
    m.nodes.push(mkNode("ROOT", "kidneys / grounding", 396, 960, 704, "0xFF4D5EFF", "Root / kidneys. Symbolic point for grounding. Feel weight settle through the legs."))

    m.ng = []
    m.nc = []
    m.nl = []
    m.nodeEnergy = []
    for i = 0 to m.nodes.count() - 1
        m.ng.push(m.top.findNode("ng" + i.toStr()))
        m.nc.push(m.top.findNode("nc" + i.toStr()))
        m.nl.push(m.top.findNode("nl" + i.toStr()))
        m.nodeEnergy.push(0.0)
    end for

    ' ---- particle pool ------------------------------------------------------
    m.npart = 28
    m.pn = []
    m.px = []
    m.py = []
    m.pvx = []
    m.pvy = []
    m.plife = []
    m.pmax = []
    m.pph = []
    m.psz = []
    m.pkind = []
    for i = 0 to m.npart - 1
        m.pn.push(m.top.findNode("p" + i.toStr()))
        m.px.push(0.0)
        m.py.push(0.0)
        m.pvx.push(0.0)
        m.pvy.push(0.0)
        m.plife.push(0.0)
        m.pmax.push(1.0)
        m.pph.push(0.0)
        m.psz.push(12.0)
        m.pkind.push(0)
    end for

    ' ---- ripple pool --------------------------------------------------------
    m.rn = []
    m.rage = []
    m.rx = []
    m.ry = []
    for i = 0 to 2
        m.rn.push(m.top.findNode("rp" + i.toStr()))
        m.rage.push(-1.0)
        m.rx.push(0.0)
        m.ry.push(0.0)
    end for

    ' ---- trail --------------------------------------------------------------
    m.tn = []
    for i = 0 to 5
        m.tn.push(m.top.findNode("t" + i.toStr()))
    end for
    m.hx = []
    m.hy = []

    ' ---- state --------------------------------------------------------------
    m.hue = 200.0
    m.bri = 50.0
    m.speed = 1.0
    m.shape = "sustain"
    m.shapes = ["sustain", "bloom", "ripple", "spiral", "storm"]
    m.modeOverride = "auto"
    m.mode = "AMBIENT"
    m.autoGround = false
    m.warmth = 0.0
    m.entropy = 0.15
    m.coh = 40.0
    m.cohForced = -1.0
    m.hrForced = -1.0
    m.pulse = 72.0
    m.beatPhase = 0.0
    m.beat = 0.0
    m.pacerOn = true
    m.breathT = 0.0
    m.breath01 = 0.5
    m.sel = 3
    m.attuning = false
    m.attuneT = 0.0
    m.attuneDur = 6.0
    m.emitAcc = 0.0
    m.rippleAcc = 0.0
    m.hudAcc = 1.0
    m.washAcc = 1.0
    m.stateAcc = 0.0
    m.accent = "0x78EBFFFF"
    m.lastPhaseText = ""
    m.lastFeedSig = ""
    m.feedUrl = ""
    m.feedStatus = "no feed"
    m.logLines = []

    n = m.nodes[m.sel]
    m.cx = n.x
    m.cy = n.y
    m.tx = n.x
    m.ty = n.y
    m.vx = 0.0
    m.vy = 0.0
    for i = 0 to 23
        m.hx.push(n.x)
        m.hy.push(n.y)
    end for

    m.nl[m.sel].color = "0xFFFFFFFF"
    updateNodePanel()
    m.keyLabel.text = "UP/DOWN    pick point" + m.NL + "OK         attune 6s" + m.NL + "LEFT/RIGHT hue" + m.NL + "PLAY       breath pacer" + m.NL + "FF / REW   lighter / heavier" + m.NL + "OPTIONS    cycle shape" + m.NL + "REPLAY     auto/amb/ground" + m.NL + "-- ECP /input? --" + m.NL + "hue bri speed shape mode" + m.NL + "node pulse attune coh hr" + m.NL + "pacer feed reset"

    ' ---- two-way feed task --------------------------------------------------
    m.feed = CreateObject("roSGNode", "FeedTask")
    m.feed.observeField("telemetry", "onFeedTelemetry")
    m.feed.observeField("status", "onFeedStatus")
    reg = CreateObject("roRegistrySection", "temple")
    if reg.exists("feed")
        setFeedUrl(reg.read("feed"))
    end if
    m.feed.control = "RUN"

    addLog("temple online. press OK to attune")

    ' ---- frame loop ---------------------------------------------------------
    m.clock = CreateObject("roTimespan")
    m.clock.mark()
    m.lastT = 0.0
    m.time = 0.0
    m.timer = CreateObject("roSGNode", "Timer")
    m.timer.duration = 0.04
    m.timer.repeat = true
    m.timer.observeField("fire", "onFrameTick")
    m.timer.control = "start"
end sub

function mkNode(name as String, organ as String, hz as Integer, x as Float, y as Float, col as String, desc as String) as Object
    return { name: name, organ: organ, hz: hz, x: x, y: y, col: col, desc: desc }
end function

' ============================================================================
'  Frame tick
' ============================================================================
sub onFrameTick()
    t = m.clock.totalMilliseconds() / 1000.0
    dt = t - m.lastT
    m.lastT = t
    if dt > 0.1 then dt = 0.1
    if dt < 0.005 then dt = 0.005
    m.time = t

    updateEntropyAndMode(dt)
    updateBreath(dt)
    updatePulse(dt)
    updateCoherence(dt)
    updateAttune(dt)
    updateCursor(dt)
    updateNodes(dt)
    emitContinuous(dt)
    updateParticles(dt)
    updateRipples(dt)

    m.washAcc = m.washAcc + dt
    if m.washAcc >= 0.12
        m.washAcc = 0.0
        updateWash()
    end if

    m.hudAcc = m.hudAcc + dt
    if m.hudAcc >= 0.25
        m.hudAcc = 0.0
        updateHud()
    end if

    ' closed loop: tell the host how the room is doing every ~4 s
    m.stateAcc = m.stateAcc + dt
    if m.stateAcc >= 4.0
        m.stateAcc = 0.0
        sendEvent("state")
    end if
end sub

' ---------------------------------------------------------------- entropy / mode
sub updateEntropyAndMode(dt as Float)
    m.entropy = m.entropy * (1.0 - 0.35 * dt)
    spd = Sqr(m.vx * m.vx + m.vy * m.vy)
    m.entropy = m.entropy + dt * clampF(spd / 1500.0, 0.0, 1.0) * 0.2
    if m.shape = "storm" then m.entropy = m.entropy + dt * 0.12
    m.entropy = clampF(m.entropy, 0.0, 1.0)

    target = 0.0
    if m.modeOverride = "ambient"
        target = 0.0
    else if m.modeOverride = "grounding"
        target = 1.0
    else
        if m.entropy > 0.6
            m.autoGround = true
        else if m.entropy < 0.28
            m.autoGround = false
        end if
        if m.autoGround then target = 1.0
    end if
    m.warmth = m.warmth + (target - m.warmth) * (1.0 - Exp(0.0 - dt * 1.2))
    if m.warmth > 0.5
        m.mode = "GROUNDING"
    else
        m.mode = "AMBIENT"
    end if
end sub

' ---------------------------------------------------------------- 4-7-8 breath
sub updateBreath(dt as Float)
    cycle = 19.0
    if m.pacerOn then m.breathT = m.breathT + dt
    ph = m.breathT - cycle * Int(m.breathT / cycle)
    m.breathPh = ph

    size01 = 0.5
    phaseText = ""
    if m.pacerOn
        remain = 0.0
        word = ""
        if ph < 4.0
            word = "INHALE"
            remain = 4.0 - ph
            size01 = smooth(ph / 4.0)
        else if ph < 11.0
            word = "HOLD"
            remain = 11.0 - ph
            size01 = 1.0
        else
            word = "EXHALE"
            remain = 19.0 - ph
            size01 = 1.0 - smooth((ph - 11.0) / 8.0)
        end if
        secs = Int(remain) + 1
        phaseText = word + "  " + secs.toStr()
    else
        phaseText = "BREATH PACER PAUSED"
    end if
    m.breath01 = size01

    if phaseText <> m.lastPhaseText
        m.lastPhaseText = phaseText
        m.phaseLabel.text = phaseText
        if m.pacerOn
            m.phaseSub.text = "4-7-8 breathing: in 4, hold 7, out 8"
        else
            m.phaseSub.text = "press PLAY to resume"
        end if
    end if

    sz = 540.0 + 250.0 * size01
    m.breathRing.width = sz
    m.breathRing.height = sz
    m.breathRing.translation = [960.0 - sz / 2.0, 560.0 - sz / 2.0]
    hs = 880.0 + 160.0 * size01
    m.ringHalo.width = hs
    m.ringHalo.height = hs
    m.ringHalo.translation = [960.0 - hs / 2.0, 560.0 - hs / 2.0]
    m.ringHalo.opacity = 0.10 + 0.16 * size01
    m.bodyPoster.opacity = 0.86 + 0.12 * size01
end sub

' ---------------------------------------------------------------- pulse (sim)
sub updatePulse(dt as Float)
    target = 76.0 - 16.0 * m.coh / 100.0 + 2.0 * Sin(m.time * 0.35)
    if m.hrForced > 0 then target = m.hrForced
    m.pulse = m.pulse + (target - m.pulse) * (1.0 - Exp(0.0 - dt * 0.5))
    m.beatPhase = m.beatPhase + dt * m.pulse / 60.0
    bp = m.beatPhase - Int(m.beatPhase)
    b = Exp(0.0 - bp * 9.0) + 0.4 * Exp(0.0 - Abs(bp - 0.2) * 28.0)
    m.beat = clampF(b, 0.0, 1.0)
end sub

' ---------------------------------------------------------------- coherence
sub updateCoherence(dt as Float)
    esum = 0.0
    for i = 0 to m.nodeEnergy.count() - 1
        esum = esum + m.nodeEnergy[i]
    end for
    esum = esum / m.nodeEnergy.count()

    target = 28.0 + 34.0 * (1.0 - m.entropy) + 20.0 * esum
    if m.pacerOn then target = target + 18.0
    if m.attuning then target = target + 6.0
    target = clampF(target, 0.0, 100.0)
    if m.cohForced >= 0 then target = m.cohForced
    m.coh = m.coh + (target - m.coh) * (1.0 - Exp(0.0 - dt * 0.6))
end sub

' ---------------------------------------------------------------- attune
sub updateAttune(dt as Float)
    if m.attuning
        m.attuneT = m.attuneT + dt
        prog = m.attuneT / m.attuneDur
        if prog >= 1.0
            completeAttune()
        else
            m.attuneBar.width = 4.0 + 376.0 * prog
            m.attuneLabel.text = "ATTUNING  " + Int(prog * 100.0).toStr() + " %   (OK to cancel)"
        end if
    end if
end sub

sub toggleAttune()
    if m.attuning
        m.attuning = false
        m.attuneT = 0.0
        m.audio.control = "stop"
        resetAttuneBar()
        addLog("attune cancelled")
        sendEvent("cancel")
    else
        startAttune()
    end if
end sub

sub startAttune()
    m.attuning = true
    m.attuneT = 0.0
    n = m.nodes[m.sel]
    playTone(m.sel)
    spawnRipple(n.x, n.y, n.col)
    burst(n.x, n.y, 8, n.col)
    addLog("attune " + n.name + " " + n.hz.toStr() + "Hz")
    sendEvent("start")
    bump(0.05)
end sub

sub completeAttune()
    n = m.nodes[m.sel]
    m.attuning = false
    m.attuneT = 0.0
    m.nodeEnergy[m.sel] = clampF(m.nodeEnergy[m.sel] + 0.6, 0.0, 1.0)
    spawnRipple(n.x, n.y, n.col)
    burst(n.x, n.y, 18, n.col)
    resetAttuneBar()
    m.attuneLabel.text = n.name + " attuned"
    addLog(n.name + " attuned")
    sendEvent("done")
end sub

sub resetAttuneBar()
    m.attuneBar.width = 2
    m.attuneLabel.text = "OK = attune this point (6 s tone)"
end sub

sub playTone(idx as Integer)
    c = CreateObject("roSGNode", "ContentNode")
    c.url = "pkg:/audio/tone_" + m.nodes[idx].hz.toStr() + ".mp3"
    c.streamFormat = "mp3"
    m.audio.control = "stop"
    m.audio.content = c
    m.audio.control = "play"
end sub

' ---------------------------------------------------------------- cursor
function massFromSpeed() as Float
    return 1.0 / clampF(m.speed, 0.02, 2.5)
end function

sub updateCursor(dt as Float)
    n = m.nodes[m.sel]
    amp = 14.0 + 40.0 * m.entropy
    if m.shape = "storm" then amp = amp + 70.0
    m.tx = n.x + amp * Cos(m.time * 0.7 + 1.3) + 0.4 * amp * Sin(m.time * 1.9)
    m.ty = n.y + amp * 0.7 * Sin(m.time * 0.9)

    mass = massFromSpeed()
    k = 22.0
    zeta = 0.5 + 0.45 * m.warmth
    c = 2.0 * zeta * Sqr(k * mass)
    ax = (0.0 - k * (m.cx - m.tx) - c * m.vx) / mass
    ay = (0.0 - k * (m.cy - m.ty) - c * m.vy) / mass
    m.vx = m.vx + ax * dt
    m.vy = m.vy + ay * dt
    m.cx = m.cx + m.vx * dt
    m.cy = m.cy + m.vy * dt

    ' visuals: heavier mass => larger, denser halo
    hsz = 80.0 + 14.0 * Sqr(mass)
    m.cursorHalo.width = hsz
    m.cursorHalo.height = hsz
    m.cursorHalo.translation = [m.cx - hsz / 2.0, m.cy - hsz / 2.0]
    m.cursorHalo.opacity = 0.35 + 0.25 * m.warmth + 0.2 * m.beat

    prog = 0.0
    if m.attuning then prog = m.attuneT / m.attuneDur
    rsz = 56.0 + 8.0 * Sin(m.time * 3.0) + 46.0 * prog
    m.cursorRing.width = rsz
    m.cursorRing.height = rsz
    m.cursorRing.translation = [m.cx - rsz / 2.0, m.cy - rsz / 2.0]
    m.cursorCore.translation = [m.cx - 9.0, m.cy - 9.0]

    ' trail
    m.hx.unshift(m.cx)
    m.hy.unshift(m.cy)
    if m.hx.count() > 24
        m.hx.pop()
        m.hy.pop()
    end if
    vmag = clampF(Sqr(m.vx * m.vx + m.vy * m.vy) / 90.0, 0.0, 1.0)
    for i = 0 to 5
        idx = (i + 1) * 3 - 1
        sz = 28.0 - i * 3.5
        tp = m.tn[i]
        tp.width = sz
        tp.height = sz
        tp.translation = [m.hx[idx] - sz / 2.0, m.hy[idx] - sz / 2.0]
        tp.opacity = (0.5 - i * 0.07) * (0.25 + 0.75 * vmag)
    end for
end sub

' ---------------------------------------------------------------- body points
sub updateNodes(dt as Float)
    for i = 0 to m.nodes.count() - 1
        n = m.nodes[i]
        e = m.nodeEnergy[i] - 0.01 * dt
        if e < 0.0 then e = 0.0
        m.nodeEnergy[i] = e

        dx = m.cx - n.x
        dy = m.cy - n.y
        d = Sqr(dx * dx + dy * dy)
        prox = clampF(1.0 - d / 260.0, 0.0, 1.0)

        sz = 64.0 + 26.0 * e + 30.0 * prox
        op = 0.35 + 0.35 * e + 0.3 * prox
        csz = 16.0 + 8.0 * prox
        if i = m.sel
            sz = sz + 34.0 + 10.0 * Sin(m.time * 3.0)
            op = 0.95
            csz = csz + 8.0
            if m.attuning then sz = sz + 40.0 * (m.attuneT / m.attuneDur)
        end if
        if n.name = "HEART"
            sz = sz + 44.0 * m.beat
            op = clampF(op + 0.25 * m.beat, 0.0, 1.0)
        end if

        g = m.ng[i]
        g.width = sz
        g.height = sz
        g.translation = [n.x - sz / 2.0, n.y - sz / 2.0]
        g.opacity = op
        c = m.nc[i]
        c.width = csz
        c.height = csz
        c.translation = [n.x - csz / 2.0, n.y - csz / 2.0]
    end for
end sub

sub selectNode(i as Integer)
    cnt = m.nodes.count()
    if i < 0 then i = cnt - 1
    if i >= cnt then i = 0
    if m.attuning
        m.attuning = false
        m.attuneT = 0.0
        m.audio.control = "stop"
        resetAttuneBar()
    end if
    m.nl[m.sel].color = "0xBFEFFFAA"
    m.sel = i
    m.nl[i].color = "0xFFFFFFFF"
    updateNodePanel()
    n = m.nodes[i]
    spawnRipple(n.x, n.y, n.col)
    sendEvent("select")
end sub

sub updateNodePanel()
    n = m.nodes[m.sel]
    m.nodeTitle.text = n.name + "  -  " + n.organ
    m.nodeFreq.text = n.hz.toStr() + " Hz  |  solfeggio resonance point"
    m.nodeDesc.text = n.desc
    resetAttuneBar()
end sub

' ============================================================================
'  Particles + ripples
' ============================================================================
sub emitContinuous(dt as Float)
    rate = 5.0
    if m.shape = "bloom"
        rate = 3.0
    else if m.shape = "ripple"
        rate = 2.0
    else if m.shape = "spiral"
        rate = 9.0
    else if m.shape = "storm"
        rate = 45.0
    end if
    m.emitAcc = m.emitAcc + rate * dt * (0.6 + m.entropy)
    while m.emitAcc >= 1.0
        m.emitAcc = m.emitAcc - 1.0
        spawnShapeParticle()
    end while

    if m.shape = "ripple"
        m.rippleAcc = m.rippleAcc + dt
        if m.rippleAcc >= 1.6
            m.rippleAcc = 0.0
            spawnRipple(m.cx, m.cy, m.nodes[m.sel].col)
        end if
    end if
end sub

sub spawnShapeParticle()
    col = m.nodes[m.sel].col
    i = freeParticle()
    if i < 0 then return
    ang = rf(0.0, 2.0 * m.PI)
    m.pkind[i] = 0
    m.pph[i] = ang
    m.px[i] = m.cx + rf(-40.0, 40.0)
    m.py[i] = m.cy + rf(-40.0, 40.0)
    m.pvx[i] = rf(-12.0, 12.0)
    m.pvy[i] = rf(-30.0, -14.0)
    m.pmax[i] = rf(5.0, 8.0)
    m.psz[i] = rf(10.0, 22.0)
    if m.shape = "bloom"
        sp = rf(70.0, 220.0)
        m.px[i] = m.cx
        m.py[i] = m.cy
        m.pvx[i] = sp * Cos(ang)
        m.pvy[i] = sp * Sin(ang)
        m.pmax[i] = rf(1.6, 2.6)
        m.psz[i] = rf(14.0, 30.0)
    else if m.shape = "spiral"
        m.pmax[i] = rf(3.0, 4.5)
        m.psz[i] = rf(10.0, 18.0)
    else if m.shape = "storm"
        sp = rf(220.0, 460.0)
        m.px[i] = m.cx
        m.py[i] = m.cy
        m.pvx[i] = sp * Cos(ang)
        m.pvy[i] = sp * Sin(ang)
        m.pmax[i] = rf(0.7, 1.3)
        m.psz[i] = rf(8.0, 16.0)
    end if
    m.plife[i] = m.pmax[i]
    m.pn[i].blendColor = col
end sub

sub burst(x as Float, y as Float, count as Integer, col as String)
    for k = 1 to count
        i = freeParticle()
        if i < 0 then return
        ang = rf(0.0, 2.0 * m.PI)
        sp = rf(90.0, 300.0)
        m.pkind[i] = 1
        m.px[i] = x
        m.py[i] = y
        m.pvx[i] = sp * Cos(ang)
        m.pvy[i] = sp * Sin(ang)
        m.pmax[i] = rf(1.4, 2.4)
        m.plife[i] = m.pmax[i]
        m.psz[i] = rf(14.0, 28.0)
        m.pph[i] = ang
        m.pn[i].blendColor = col
    end for
end sub

function freeParticle() as Integer
    for i = 0 to m.npart - 1
        if m.plife[i] <= 0.0 then return i
    end for
    return -1
end function

sub updateParticles(dt as Float)
    for i = 0 to m.npart - 1
        life = m.plife[i]
        if life > 0.0
            life = life - dt
            p = m.pn[i]
            if life <= 0.0
                m.plife[i] = 0.0
                p.opacity = 0.0
            else
                m.plife[i] = life
                f = life / m.pmax[i]
                x = 0.0
                y = 0.0
                if m.pkind[i] = 0 and m.shape = "spiral"
                    m.pph[i] = m.pph[i] + dt * (1.8 + 3.0 * (1.0 - f))
                    r = 24.0 + (1.0 - f) * 150.0
                    x = m.cx + r * Cos(m.pph[i])
                    y = m.cy + r * 0.8 * Sin(m.pph[i])
                else
                    drag = 0.4
                    if m.pkind[i] = 1 or m.shape = "bloom"
                        drag = 1.8
                    else if m.shape = "storm"
                        drag = 0.6
                    end if
                    kdec = Exp(0.0 - drag * dt)
                    m.pvx[i] = m.pvx[i] * kdec
                    m.pvy[i] = m.pvy[i] * kdec
                    if m.pkind[i] = 0 and m.shape = "sustain"
                        m.pvx[i] = m.pvx[i] + 18.0 * Sin(m.time * 1.3 + m.pph[i]) * dt
                    end if
                    m.px[i] = m.px[i] + m.pvx[i] * dt
                    m.py[i] = m.py[i] + m.pvy[i] * dt
                    x = m.px[i]
                    y = m.py[i]
                end if

                a = 4.0 * f * (1.0 - f)
                grow = 0.8
                if m.pkind[i] = 1 or m.shape = "bloom" or m.shape = "storm"
                    a = f
                    grow = 0.6 + 0.8 * (1.0 - f)
                end if
                sz = m.psz[i] * grow
                p.width = sz
                p.height = sz
                p.translation = [x - sz / 2.0, y - sz / 2.0]
                p.opacity = clampF(a * 0.9, 0.0, 1.0)
            end if
        end if
    end for
end sub

sub spawnRipple(x as Float, y as Float, col as String)
    for i = 0 to 2
        if m.rage[i] < 0.0
            m.rage[i] = 0.0
            m.rx[i] = x
            m.ry[i] = y
            m.rn[i].blendColor = col
            return
        end if
    end for
end sub

sub updateRipples(dt as Float)
    for i = 0 to 2
        if m.rage[i] >= 0.0
            m.rage[i] = m.rage[i] + dt
            f = m.rage[i] / 2.0
            r = m.rn[i]
            if f >= 1.0
                m.rage[i] = -1.0
                r.opacity = 0.0
            else
                sz = 40.0 + 380.0 * f
                r.width = sz
                r.height = sz
                r.translation = [m.rx[i] - sz / 2.0, m.ry[i] - sz / 2.0]
                r.opacity = (1.0 - f) * 0.8
            end if
        end if
    end for
end sub

sub killParticles()
    for i = 0 to m.npart - 1
        m.plife[i] = 0.0
        m.pn[i].opacity = 0.0
    end for
end sub

' ============================================================================
'  Wash / HUD
' ============================================================================
sub updateWash()
    diff = 28.0 - m.hue
    if diff > 180.0 then diff = diff - 360.0
    if diff < -180.0 then diff = diff + 360.0
    eff = wrapHue(m.hue + diff * m.warmth)

    sat = 0.58 - 0.08 * m.warmth
    v = 0.04 + 0.30 * (m.bri / 100.0)
    v = v * (0.9 + 0.2 * m.breath01)
    rgb = hsv2rgb(eff, sat, v)
    m.bgWash.color = "0x" + hex2(rgb.r) + hex2(rgb.g) + hex2(rgb.b) + "FF"

    ac = hsv2rgb(eff, 0.50, 1.0)
    m.accent = "0x" + hex2(ac.r) + hex2(ac.g) + hex2(ac.b) + "FF"
    m.breathRing.blendColor = m.accent
    m.ringHalo.blendColor = m.accent
    m.cursorHalo.blendColor = m.accent
    m.modeLabel.color = m.accent
    for i = 0 to 5
        m.tn[i].blendColor = m.accent
    end for
    m.modeLabel.text = m.mode
    if m.modeOverride <> "auto" then m.modeLabel.text = m.mode + "  (locked)"
end sub

sub updateHud()
    mass = massFromSpeed()
    n = m.nodes[m.sel]

    setMetric(0, Int(m.coh).toStr() + " %", m.coh / 100.0)
    setMetric(1, Int(m.pulse + 0.5).toStr() + " bpm", (m.pulse - 45.0) / 60.0)
    if m.pacerOn
        setMetric(2, f1(60.0 / 19.0) + " /min", m.breathPh / 19.0)
    else
        setMetric(2, "paused", 0.0)
    end if
    setMetric(3, n.hz.toStr() + " Hz", n.hz / 1000.0)
    setMetric(4, Int(m.entropy * 100.0).toStr() + " %", m.entropy)
    setMetric(5, f1(mass) + " kg", Log(mass * 2.5) / Log(125.0))

    t = "MODE   " + m.mode + " (" + UCase(m.modeOverride) + ")" + m.NL
    t = t + "SHAPE  " + UCase(m.shape) + m.NL
    t = t + "HUE    " + Int(m.hue).toStr() + " deg" + m.NL
    t = t + "LUMA   " + Int(m.bri).toStr() + " %" + m.NL
    t = t + "SPEED  " + f2(m.speed) + "x  MASS " + f1(mass) + " kg" + m.NL
    t = t + "FEED   " + m.feedStatus
    m.telemetryLabel.text = t
end sub

sub setMetric(i as Integer, txt as String, frac as Float)
    m.mv[i].text = txt
    m.mb[i].width = 4.0 + 356.0 * clampF(frac, 0.0, 1.0)
end sub

sub addLog(s as String)
    m.logLines.push(s)
    while m.logLines.count() > 6
        m.logLines.shift()
    end while
    txt = ""
    for each line in m.logLines
        txt = txt + "> " + line + m.NL
    end for
    m.logLabel.text = txt
end sub

' ============================================================================
'  Input: remote keys
' ============================================================================
function onKeyEvent(key as String, press as Boolean) as Boolean
    if not press then return false
    handled = true
    if key = "down"
        selectNode(m.sel + 1)
    else if key = "up"
        selectNode(m.sel - 1)
    else if key = "left"
        m.hue = wrapHue(m.hue - 15.0)
    else if key = "right"
        m.hue = wrapHue(m.hue + 15.0)
    else if key = "OK"
        toggleAttune()
    else if key = "play"
        m.pacerOn = not m.pacerOn
        addLog("pacer " + onOff(m.pacerOn))
    else if key = "fastforward"
        m.speed = clampF(m.speed * 1.5, 0.02, 2.5)
        addLog("lighter: speed " + f2(m.speed) + "x")
    else if key = "rewind"
        m.speed = clampF(m.speed / 1.5, 0.02, 2.5)
        addLog("heavier: speed " + f2(m.speed) + "x")
    else if key = "options"
        cycleShape()
    else if key = "replay"
        cycleMode()
    else
        handled = false
    end if
    if handled then bump(0.04)
    return handled
end function

sub cycleShape()
    idx = 0
    for i = 0 to m.shapes.count() - 1
        if m.shapes[i] = m.shape then idx = i
    end for
    setShape(m.shapes[(idx + 1) mod m.shapes.count()])
end sub

sub setShape(s as String)
    if s = m.shape then return
    m.shape = s
    killParticles()
    m.emitAcc = 0.0
    addLog("shape " + UCase(s))
end sub

sub cycleMode()
    if m.modeOverride = "auto"
        m.modeOverride = "ambient"
    else if m.modeOverride = "ambient"
        m.modeOverride = "grounding"
    else
        m.modeOverride = "auto"
    end if
    addLog("mode " + m.modeOverride)
end sub

sub bump(v as Float)
    m.entropy = clampF(m.entropy + v, 0.0, 1.0)
end sub

' ============================================================================
'  Input: ECP launch args, ECP /input, HTTP feed
' ============================================================================
sub onLaunchParamsChange()
    p = m.top.launchParams
    if p = invalid then return
    applyParams(p, "LAUNCH")
end sub

sub onInputParams()
    p = m.top.inputParams
    if p = invalid then return
    applyParams(p, "ECP")
end sub

sub onFeedTelemetry()
    t = m.feed.telemetry
    if t = invalid then return
    sig = FormatJson(t)
    if sig = m.lastFeedSig then return
    m.lastFeedSig = sig
    applyParams(t, "FEED")
end sub

sub onFeedStatus()
    s = m.feed.status
    if s <> m.feedStatus
        m.feedStatus = s
        addLog("feed " + s)
    end if
end sub

sub setFeedUrl(url as String)
    m.feedUrl = url
    m.feed.feedUrl = url
    reg = CreateObject("roRegistrySection", "temple")
    if url = ""
        reg.delete("feed")
        m.feedStatus = "no feed"
    else
        reg.write("feed", url)
        m.feedStatus = "connecting"
    end if
    reg.flush()
end sub

sub applyParams(p as Object, src as String)
    if type(p) <> "roAssociativeArray" then return
    logTxt = ""
    v = getP(p, "hue")
    if v <> invalid
        m.hue = wrapHue(toF(v, m.hue))
        logTxt = logTxt + " hue=" + Int(m.hue).toStr()
    end if
    v = getP(p, "bri")
    if v <> invalid
        m.bri = clampF(toF(v, m.bri), 0.0, 100.0)
        logTxt = logTxt + " bri=" + Int(m.bri).toStr()
    end if
    v = getP(p, "speed")
    if v <> invalid
        m.speed = clampF(toF(v, m.speed), 0.02, 2.5)
        logTxt = logTxt + " speed=" + f2(m.speed)
    end if
    v = getP(p, "shape")
    if v <> invalid
        s = LCase(v.toStr())
        for i = 0 to m.shapes.count() - 1
            if m.shapes[i] = s then setShape(s)
        end for
        logTxt = logTxt + " shape=" + s
    end if
    v = getP(p, "mode")
    if v <> invalid
        s = LCase(v.toStr())
        if s = "auto" or s = "ambient" or s = "grounding" then m.modeOverride = s
        logTxt = logTxt + " mode=" + s
    end if
    v = getP(p, "coh")
    if v <> invalid
        m.cohForced = toF(v, -1.0)
        logTxt = logTxt + " coh=" + Int(m.cohForced).toStr()
    end if
    v = getP(p, "hr")
    if v <> invalid
        m.hrForced = toF(v, -1.0)
        logTxt = logTxt + " hr=" + Int(m.hrForced).toStr()
    end if
    v = getP(p, "pacer")
    if v <> invalid
        s = LCase(v.toStr())
        m.pacerOn = (s = "on" or s = "1" or s = "true")
        logTxt = logTxt + " pacer=" + s
    end if
    v = getP(p, "node")
    if v <> invalid
        idx = findNodeIndex(v.toStr())
        if idx >= 0 then selectNode(idx)
        logTxt = logTxt + " node=" + LCase(v.toStr())
    end if
    v = getP(p, "feed")
    if v <> invalid
        setFeedUrl(v.toStr())
        logTxt = logTxt + " feed"
    end if
    v = getP(p, "reset")
    if v <> invalid
        m.entropy = 0.15
        m.cohForced = -1.0
        m.hrForced = -1.0
        m.modeOverride = "auto"
        m.speed = 1.0
        for i = 0 to m.nodeEnergy.count() - 1
            m.nodeEnergy[i] = 0.0
        end for
        logTxt = logTxt + " reset"
    end if
    v = getP(p, "pulse")
    if v <> invalid
        n = m.nodes[m.sel]
        burst(m.cx, m.cy, 14, n.col)
        spawnRipple(m.cx, m.cy, n.col)
        logTxt = logTxt + " pulse"
    end if
    v = getP(p, "attune")
    if v <> invalid
        if not m.attuning then startAttune()
        logTxt = logTxt + " attune"
    end if

    if src <> "FEED" then bump(0.15)
    if logTxt <> "" then addLog(LCase(src) + logTxt)
    updateWash()
end sub

function findNodeIndex(s as String) as Integer
    ls = LCase(s)
    for i = 0 to m.nodes.count() - 1
        if LCase(m.nodes[i].name) = ls then return i
    end for
    if ls = "0" or ls = "1" or ls = "2" or ls = "3" or ls = "4" or ls = "5" or ls = "6"
        return ls.toInt()
    end if
    return -1
end function

sub sendEvent(kind as String)
    if m.feedUrl = "" then return
    n = m.nodes[m.sel]
    q = "/event?type=" + kind + "&node=" + LCase(n.name) + "&hz=" + n.hz.toStr()
    q = q + "&coh=" + Int(m.coh).toStr() + "&ent=" + Int(m.entropy * 100.0).toStr()
    q = q + "&mode=" + LCase(m.mode) + "&t=" + Int(m.time * 1000.0).toStr()
    m.feed.outbox = q
end sub

' ============================================================================
'  Helpers
' ============================================================================
function getP(p as Object, key as String) as Dynamic
    if p.doesExist(key) then return p[key]
    return invalid
end function

function toF(v as Dynamic, def as Float) as Float
    t = type(v)
    if t = "roString" or t = "String"
        s = v.trim()
        if s = "" then return def
        return s.toFloat()
    else if t = "Float" or t = "roFloat" or t = "Integer" or t = "roInt" or t = "Double" or t = "roDouble"
        return v
    end if
    return def
end function

function onOff(b as Boolean) as String
    if b then return "on"
    return "off"
end function

function rf(lo as Float, hi as Float) as Float
    return lo + (hi - lo) * Rnd(0)
end function

function clampF(v as Float, lo as Float, hi as Float) as Float
    if v < lo then return lo
    if v > hi then return hi
    return v
end function

function smooth(t as Float) as Float
    t = clampF(t, 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)
end function

function fmodF(a as Float, b as Float) as Float
    r = a - b * Int(a / b)
    if r < 0.0 then r = r + b
    return r
end function

function wrapHue(h as Float) as Float
    return fmodF(h, 360.0)
end function

function f1(v as Float) as String
    n = Int(v * 10.0 + 0.5)
    whole = n \ 10
    frac = n mod 10
    return whole.toStr() + "." + frac.toStr()
end function

function f2(v as Float) as String
    n = Int(v * 100.0 + 0.5)
    whole = n \ 100
    frac = n mod 100
    fs = frac.toStr()
    if frac < 10 then fs = "0" + fs
    return whole.toStr() + "." + fs
end function

function hex2(v as Integer) as String
    chars = "0123456789ABCDEF"
    if v < 0 then v = 0
    if v > 255 then v = 255
    return Mid(chars, (v \ 16) + 1, 1) + Mid(chars, (v mod 16) + 1, 1)
end function

function hsv2rgb(h as Float, s as Float, v as Float) as Object
    c = v * s
    hp = fmodF(h, 360.0) / 60.0
    x = c * (1.0 - Abs(fmodF(hp, 2.0) - 1.0))
    mm = v - c
    r = 0.0
    g = 0.0
    b = 0.0
    if hp < 1.0
        r = c
        g = x
    else if hp < 2.0
        r = x
        g = c
    else if hp < 3.0
        g = c
        b = x
    else if hp < 4.0
        g = x
        b = c
    else if hp < 5.0
        r = x
        b = c
    else
        r = c
        b = x
    end if
    return { r: Int((r + mm) * 255.0), g: Int((g + mm) * 255.0), b: Int((b + mm) * 255.0) }
end function

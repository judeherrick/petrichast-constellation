' FeedTask - background thread. Two-way link to the haptic engine:
'   IN : polls {feedUrl}/telemetry.json every 2s  -> telemetry field
'   OUT: GETs {feedUrl}{outbox} whenever the scene writes the outbox field

sub init()
    m.top.functionName = "runLoop"
end sub

sub runLoop()
    port = CreateObject("roMessagePort")
    m.top.observeField("outbox", port)
    m.top.observeField("feedUrl", port)

    while true
        msg = wait(2000, port)
        if msg = invalid
            pollFeed()
        else if type(msg) = "roSGNodeEvent"
            fld = msg.getField()
            if fld = "outbox"
                sendOutbox(msg.getData())
            else if fld = "feedUrl"
                pollFeed()
            end if
        end if
    end while
end sub

sub pollFeed()
    base = m.top.feedUrl
    if base = invalid or base = "" then return
    body = httpGet(base + "/telemetry.json")
    if body = ""
        m.top.status = "offline"
        return
    end if
    obj = ParseJson(body)
    if obj <> invalid and type(obj) = "roAssociativeArray"
        m.top.status = "linked"
        m.top.telemetry = obj
    else
        m.top.status = "badjson"
    end if
end sub

sub sendOutbox(path as Dynamic)
    base = m.top.feedUrl
    if base = invalid or base = "" then return
    if type(path) <> "roString" and type(path) <> "String" then return
    httpGet(base + path)
end sub

function httpGet(url as String) as String
    xfer = CreateObject("roUrlTransfer")
    xfer.setUrl(url)
    xfer.retainBodyOnError(true)
    s = xfer.getToString()
    if s = invalid then return ""
    return s
end function

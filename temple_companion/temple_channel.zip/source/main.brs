' Scombinatorial Temple Companion v2 - entry point
' Boots the SceneGraph screen, forwards launch args (ECP /launch) and live
' ECP /input messages (roInputEvent) into the scene as assocarray fields.

sub Main(args as Object)
    screen = CreateObject("roSGScreen")
    port = CreateObject("roMessagePort")
    screen.setMessagePort(port)

    ' Live ECP "POST /input?hue=..&bri=.." messages arrive as roInputEvent
    input = CreateObject("roInput")
    input.setMessagePort(port)

    scene = screen.CreateScene("MainScene")
    screen.show()

    if args <> invalid and args.count() > 0
        scene.launchParams = args
    end if

    seq = 0
    while true
        msg = wait(0, port)
        msgType = type(msg)
        if msgType = "roSGScreenEvent"
            if msg.isScreenClosed() then return
        else if msgType = "roInputEvent"
            if msg.isInput()
                info = msg.getInfo()
                if info <> invalid
                    ' sequence stamp so identical repeats still fire onChange
                    seq = seq + 1
                    info["_seq"] = seq
                    scene.inputParams = info
                end if
            end if
        end if
    end while
end sub
